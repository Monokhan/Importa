# Importa · Plan de lanzamiento

**Tu negocio importa.**

---

## 1. Sistema de marca

**Nombre:** Importa
**Lema principal:** Tu negocio importa.

El lema funciona en dos sentidos a la vez: *importar* (traer mercadería) e *importar* (ser importante). Úsalo siempre completo y con punto final.

### Frases derivadas

| Uso | Frase |
|---|---|
| Promesa del producto | Importa sin adivinar. |
| Costeo | Tu costo real importa. |
| Márgenes | Lo que importa es tu margen. |
| Finanzas | Cada peso importa. |
| Llamado a la acción | Importa bien. Vende mejor. |
| Cumplimiento legal | Importa en regla. |
| Comunidad | Pymes que importan. |

### Nombres de funciones

Importa Costeo · Importa Fletes · Importa Precios · Importa F29 · Importa Academia (guía y glosario) · Importa Pro (plan pagado).

### Voz

Directa, cercana y con números. Tuteo. Frases cortas. Cada afirmación con un ejemplo concreto. Nunca prometer ganancias; mostrar cómo calcularlas.

### Etiquetas

Propias: `#TuNegocioImporta` `#ImportaConNúmeros`
De alcance: `#PymeChile` `#EmprendimientoChile` `#ImportarDesdeChina` `#VenderEnMercadoLibre`

Usa 3 a 5 por publicación en Instagram, 2 a 3 en LinkedIn y 1 o 2 en Facebook.

### Antes de registrar

«Importa» es una palabra de uso común, lo que hace más difícil registrarla sola. Conviene registrarla en INAPI como **marca mixta** (logo + nombre + lema) en las clases 9 (software), 35 (servicios comerciales) y 42 (software como servicio), y revisar la disponibilidad de `importa.cl` en NIC Chile y de `@importa.cl` o `@importa.app` en redes.

---

## 2. Perfiles

| Red | Foto de perfil | Portada |
|---|---|---|
| LinkedIn (página de empresa) | `perfil_1080x1080.png` | `portada_linkedin_1128x191.png` |
| LinkedIn (perfil personal del fundador) | tu foto | `portada_linkedin_personal_1584x396.png` |
| Facebook | `perfil_1080x1080.png` | `portada_facebook_1640x624.png` |
| Instagram | `perfil_1080x1080.png` | — |

**Biografía de Instagram (150 caracteres):**
> Tu negocio importa. 📦
> Costea, importa y vende con el costo real a la vista.
> Hecho para pymes chilenas 🇨🇱
> ↓ Pruébala

**Descripción de Facebook y LinkedIn:**
> Importa es la app que le dice a las pymes chilenas cuánto les cuesta de verdad cada producto que importan, a qué precio venderlo en cada canal y cuánto IVA declarar en su F29. Costeo aduanero, comparador de fletes, márgenes por canal y una guía paso a paso de cero a la primera venta.

---

## 3. Semana de lanzamiento: 7 publicaciones, una por día

Cada publicación usa la misma imagen en las tres redes (formato 4:5, 1080 × 1350). El texto cambia: Instagram y Facebook son más cercanos; LinkedIn, más profesional.

| Día | Imagen | Objetivo | Tema |
|---|---|---|---|
| Lunes | `post_1_lanzamiento.png` | Presentar | Lanzamiento |
| Martes | `post_2_iva.png` | Educar | El IVA de importación no es costo |
| Miércoles | `post_3_landed.png` | Demostrar | Costo real puesto en bodega |
| Jueves | `post_4_flete.png` | Demostrar | Marítimo vs. aéreo |
| Viernes | `post_5_ml.png` | Educar | Costos ocultos en Mercado Libre |
| Sábado | `post_6_spa.png` | Educar | SpA o persona natural |
| Domingo | `post_7_cta.png` | Convertir | Llamado a probar la app |

Horarios sugeridos para partir: entre 12:30 y 14:00 o entre 19:00 y 21:00. Después de dos semanas, mira en las estadísticas de cada red a qué hora está conectada tu audiencia y ajusta.

---

### Día 1 · Lunes · Lanzamiento

**Instagram y Facebook**
> Tu negocio importa. Y por eso creamos Importa. 📦
>
> Si importas y vendes en Chile, seguro te pasó: el proveedor te da un precio, pero no sabes cuánto te cuesta *de verdad* cuando llega a tu bodega. Ni a qué precio vender para ganar. Ni cuánto IVA vas a pagar.
>
> Importa te lo calcula todo:
> ✓ Costo real puesto en bodega
> ✓ Precio con margen para cada canal
> ✓ Comparador de fletes
> ✓ Tu F29 del mes, listo
>
> Link en el perfil 👆
>
> #TuNegocioImporta #PymeChile #EmprendimientoChile #ImportarDesdeChina

**LinkedIn**
> Hoy lanzamos Importa.
>
> Trabajando con pymes que importan, vimos el mismo problema una y otra vez: se fija el precio de venta a partir del precio del proveedor, sin sumar flete, seguro, arancel, agente de aduana ni gastos de puerto. El margen se descubre, con suerte, a fin de mes.
>
> Importa calcula el costo real de cada producto puesto en bodega, sugiere precios por canal con margen limpio y deja listo el F29 mensual.
>
> Porque cada decisión de tu negocio importa.
>
> #TuNegocioImporta #Pymes #ComercioExterior

---

### Día 2 · Martes · El IVA no es costo

**Instagram y Facebook**
> ¿Sumas el IVA de la importación a tu costo? ❌
>
> Ese 19 % que pagas en Aduana vuelve como crédito fiscal en tu F29. Si lo cargas al costo, inflas el precio sin razón y pierdes ventas frente a tu competencia.
>
> En Importa ves por separado:
> 🔵 Tu costo real (sin IVA)
> 🟢 La plata que sale de tu caja (con IVA)
>
> Guarda este post para tu próxima importación 📌
>
> #TuNegocioImporta #IVA #F29 #PymeChile

**LinkedIn**
> Un error frecuente en pymes importadoras: tratar el IVA de importación como costo.
>
> El IVA pagado en la DIN es crédito fiscal y se descuenta del débito del mes en el F29. Sumarlo al costo unitario sobreestima el costo en un 19 % sobre la base CIF más arancel, y lleva a precios poco competitivos.
>
> La distinción correcta: costo en bodega (sin IVA) para fijar precios, desembolso de caja (con IVA) para planificar liquidez.
>
> #Tributación #Pymes #ComercioExterior

---

### Día 3 · Miércoles · Costo real

**Instagram y Facebook**
> US$ 8,50 en China. $10.293 en tu bodega. 🤯
>
> El precio del proveedor es solo el comienzo. Súmale flete, seguro, agente de aduana, puerto y transporte, y el número cambia bastante.
>
> Importa hace ese cálculo por ti, producto por producto, y te dice cuánto te cuesta realmente cada unidad.
>
> ¿Cuánto crees que te cuesta tu producto? Cuéntanos en los comentarios 👇
>
> #TuNegocioImporta #ImportarDesdeChina #CostoReal

**LinkedIn**
> El precio FOB no es el costo del producto.
>
> Ejemplo calculado con Importa: un power bank a US$ 8,50 FOB, lote de 500 unidades, flete marítimo LCL con recargo por carga peligrosa, dólar a $950. Costo puesto en bodega, sin IVA: $10.293 por unidad.
>
> La diferencia entre ambos números es donde las pymes pierden margen sin darse cuenta.
>
> #CosteoAduanero #ComercioExterior #Pymes

---

### Día 4 · Jueves · Fletes

**Instagram y Facebook**
> ¿Marítimo o aéreo? El más barato no siempre gana. ✈️🚢
>
> En este ejemplo, el aéreo cuesta $969 más por unidad… pero la mercadería llega 32 días antes. Son 32 días más vendiendo.
>
> En Importa guardas las cotizaciones de tus forwarders y ves la comparación con tu carga real. Tú decides con números.
>
> #TuNegocioImporta #Logística #ImportarDesdeChina

**LinkedIn**
> Elegir el flete solo por tarifa es una decisión incompleta.
>
> Ejemplo calculado con Importa (1,2 m³, 200 kg, FOB US$ 7.000, 1.000 unidades): marítimo LCL deja el costo en $7.664 por unidad en 40 días; aéreo, en $8.633 en 8 días.
>
> La pregunta correcta no es cuál es más barato, sino si 32 días antes de venta justifican $969 más por unidad. Depende de tu rotación y de tu caja.
>
> #Logística #SupplyChain #Pymes

---

### Día 5 · Viernes · Mercado Libre

**Instagram y Facebook**
> ¿Vendes en Mercado Libre y el margen no te cuadra? 🤔
>
> Revisa estos 3 costos:
> 1️⃣ Comisión de 13 % a 19 % según la categoría
> 2️⃣ Envío gratis desde $19.990: sobre ese precio, lo pagas tú
> 3️⃣ Publicidad sin control: si no sabes tu ROAS mínimo, pagas por vender
>
> Importa te muestra tu margen limpio en cada canal, con todo descontado.
>
> #TuNegocioImporta #MercadoLibre #VenderOnline

**LinkedIn**
> Tres costos que las pymes suelen subestimar en Mercado Libre: la comisión por categoría, el envío gratis obligatorio sobre cierto precio y la inversión en Product Ads.
>
> Calcular el margen limpio por canal, y el ROAS mínimo para no perder con publicidad, cambia qué productos conviene vender en cada plataforma.
>
> #eCommerce #Marketplaces #Pymes

---

### Día 6 · Sábado · SpA o persona natural

**Instagram y Facebook**
> ¿Vas a importar como persona natural? Piénsalo dos veces. ⚠️
>
> Como persona natural respondes con todo lo tuyo: auto, casa y ahorros.
>
> Una SpA protege tu patrimonio y se crea gratis, en el día, en tuempresaenundia.cl.
>
> La guía de Importa te lleva paso a paso de cero a tu primera importación. Confirma tu caso con tu contador.
>
> #TuNegocioImporta #SpA #EmprendimientoChile

**LinkedIn**
> Para quien empieza a importar, la forma legal importa desde el día uno.
>
> La SpA ofrece responsabilidad limitada al capital, se constituye gratis en tuempresaenundia.cl y permite sumar socios más adelante. Como persona natural con giro, la responsabilidad es ilimitada.
>
> Siempre conviene validar el caso concreto con un contador.
>
> #Emprendimiento #Pymes #Chile

---

### Día 7 · Domingo · Llamado a la acción

**Instagram y Facebook**
> Esta semana te mostramos lo que Importa puede hacer por tu negocio. Ahora te toca a ti. 👇
>
> ✓ Costo real puesto en bodega
> ✓ Precio con margen por canal
> ✓ Comparador de fletes
> ✓ F29 del mes, listo para tu contador
>
> Importa sin adivinar. Pruébala: link en el perfil.
>
> #TuNegocioImporta #ImportaConNúmeros #PymeChile

**LinkedIn**
> Importa ya está disponible para pymes chilenas que importan y venden en línea.
>
> Costeo aduanero, comparador de fletes, precios con margen limpio por canal, F29 mensual y una guía paso a paso de cero a la primera venta.
>
> Si importas o estás por hacerlo, te invito a probarla y contarnos qué te falta.
>
> #TuNegocioImporta #Pymes #ComercioExterior

---

### Después de la primera semana

Mantén un ritmo sostenible: **4 a 5 publicaciones por semana** por red, repitiendo estas categorías:

- 40 % educación (errores, cálculos, impuestos, logística)
- 25 % demostración de la app (una función por publicación)
- 20 % casos y testimonios de usuarios reales (cuando los tengas)
- 15 % llamado directo a probar

Cada educativa de buen desempeño puede convertirse en un carrusel de 5 a 7 láminas o en un Reel de 20 a 30 segundos grabando la pantalla de la app.

---

## 4. Monetización

### Qué falta en la app antes de cobrar

Hoy la app no tiene cobro. Para convertir clics en pagos se necesitan tres piezas:

1. **Página de aterrizaje** con la propuesta, capturas de la app, planes y un botón de registro.
2. **Cobro recurrente**: suscripciones con Flow o Mercado Pago, más la lógica de plan dentro de la app (qué incluye cada nivel y qué pasa al vencer).
3. **Medición**: Pixel de Meta con API de Conversiones, Google Analytics 4 y la etiqueta de conversión de Google Ads, con eventos de *registro*, *primer costeo* y *pago*.

Sin estas tres, la pauta pagada solo compra visitas que no se pueden convertir ni medir.

### Planes propuestos

Son una propuesta para validar con los primeros usuarios, no precios de mercado.

| Plan | Qué incluye | Precio propuesto |
|---|---|---|
| **Gratis** | Guía, glosario, 1 costeo al mes, comparador de 2 fletes | $0 |
| **Emprende** | Costeos y fletes ilimitados, precios por canal, ventas y stock | $9.990 al mes + IVA |
| **Pyme** | Todo lo anterior, F29 mensual, libros para el contador, dossier PDF, varios usuarios | $24.990 al mes + IVA |

Ofrece **14 días de Pyme gratis** al registrarse: el usuario prueba lo más valioso y decide con su propia importación.

---

## 5. Publicidad pagada

### Principio

La pauta se prueba con poco, se mide y se escala solo lo que convierte. Las cifras de presupuesto de abajo son un punto de partida para aprender; el presupuesto real debe salir de tus propios resultados en las primeras semanas.

### Embudo

| Etapa | Meta | Google |
|---|---|---|
| Descubrimiento | Reels y posts educativos (días 2 a 5) | — |
| Consideración | Tráfico a la página, con la guía gratuita como gancho | Búsqueda por intención |
| Conversión | Remarketing a quien visitó o interactuó | Remarketing y Performance Max |

### Meta (Instagram y Facebook)

**Campaña 1 · Descubrimiento.** Objetivo: interacción o reproducciones de video. Anuncios: publicaciones 2, 3, 4 y 5, idealmente en versión Reel. Público: Chile, 25 a 55 años, intereses en importación, comercio electrónico, Mercado Libre, Alibaba, emprendimiento y pymes.

**Campaña 2 · Registros.** Objetivo: clientes potenciales o tráfico hacia la página. Gancho: «Guía gratis: de cero a tu primera importación» o «Calcula gratis tu costo real». Público: el mismo de arriba más un público similar a tus registrados cuando tengas al menos 100.

**Campaña 3 · Remarketing.** Objetivo: conversiones (registro o prueba gratis). Público: visitantes de la página en los últimos 30 días y personas que interactuaron con tus publicaciones. Anuncio: publicación 7 y testimonios.

### Google Ads

**Búsqueda**, con palabras clave de intención alta:

- cómo importar desde china
- costo de internación chile
- calcular costo de importación
- calculadora aduana chile
- arancel e iva importación chile
- cómo declarar f29 pyme
- margen vender en mercado libre

Palabras negativas para no pagar clics inútiles: *curso*, *empleo*, *trabajo*, *seguimiento*, *tracking*, *courier* (si no quieres tráfico de envíos personales), *gratis* (evalúalo según tu plan gratuito).

Anuncio de ejemplo:
> **Titular:** Calcula tu costo de importación | Tu negocio importa
> **Descripción:** Costo real puesto en bodega, flete, arancel e IVA. Precio con margen por canal. Pruébala gratis 14 días.

**Performance Max**: actívala después, cuando ya tengas conversiones medidas, para que Google tenga datos con los que optimizar.

### Presupuesto de prueba

Para las primeras 3 semanas, reparte un presupuesto de prueba que te resulte cómodo perder aprendiendo:

- 50 % Google Búsqueda (captura a quien ya busca la solución)
- 35 % Meta registros
- 15 % Meta remarketing

Cada semana, pausa los anuncios que no generan registros y pasa ese dinero a los que sí.

### Cuánto puedes pagar por cliente

Este es el cálculo que manda sobre el presupuesto:

> **Valor de un cliente** = precio mensual neto × meses promedio que se queda
> **Costo máximo por cliente** = valor de un cliente ÷ 3

Ejemplo con los precios propuestos: si un cliente del plan Emprende se quedara 6 meses, su valor sería $9.990 × 6 = $59.940, y lo máximo sensato para conseguirlo sería cerca de $20.000. Los 6 meses son un supuesto: reemplázalo por tu permanencia real en cuanto la tengas.

### Qué medir cada semana

| Indicador | Qué te dice |
|---|---|
| Costo por registro | Cuánto pagas por cada cuenta nueva |
| Tasa de registro a pago | Qué parte de quienes prueban termina pagando |
| Costo por cliente pagado | Costo total de pauta ÷ clientes que pagaron |
| Permanencia | Cuántos meses se queda un cliente en promedio |
| Valor ÷ costo por cliente | Debe ser 3 o más para que la pauta sea rentable |

---

## 6. Siguientes pasos

1. Registrar la marca mixta en INAPI y asegurar dominio y usuarios en redes.
2. Construir la página de aterrizaje y el cobro recurrente en la app.
3. Instalar la medición (Pixel, API de Conversiones, GA4, conversión de Google Ads).
4. Publicar la semana de lanzamiento de forma orgánica.
5. Encender la pauta de prueba y revisar indicadores cada semana.
